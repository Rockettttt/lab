﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1_ABC.Entity; //Reference to Customer Entity
using Q1_ABC.Exception;//Reference to Exception Class Library
using Q1_ABC.DAL; //Reference to DAL

namespace Q1_ABC.DAL
{
    /// <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description :  Database operations on Customer Class
    /// </summary>
    public class CustomerOperations
    {
        static List<Customer> cusList = new List<Customer>();

        //To insert the Customer record in Customer list
        public static bool AddCustomer(Customer cus)
        {
            bool cusAdded = false;

            try
            {
                //Adding employee object into employee list
                cusList.Add(cus);
                cusAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusAdded;
        }

    }
}
