﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_ABC.BL
{
    // <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : Business logic class for Customer
    /// </summary>
    public class CustomerValidations
    {
    }
}
