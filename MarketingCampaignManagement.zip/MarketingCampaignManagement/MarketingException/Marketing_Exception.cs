﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingException
{

    [Serializable]
    public class Marketing_Exception : Exception
    {
        public Marketing_Exception() { }
        public Marketing_Exception(string message) : base(message) { }
        public Marketing_Exception(string message, Exception inner) : base(message, inner) { }
        protected Marketing_Exception(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
