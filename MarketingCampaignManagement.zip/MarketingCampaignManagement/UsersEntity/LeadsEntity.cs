﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingEntity
{
   public class LeadsEntity
    {
        public int LeadId { get; set; }
        public int CampaignId { get; set; }
        public string ConsumerName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNo { get; set; }
        public string PreferredModeOfCommunication { get; set; }
        public DateTime DateAppoached { get; set; }
        public int ProductId { get; set; }
        public string Status { get; set; }


    }
}
