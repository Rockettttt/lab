﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingEntity
{
    public class UsersEntity

    {
        public int UserId { get; set; }
        public string FullName{ get; set; }
        public string LoginId{ get; set; }
        public string Password { get; set; }
        public DateTime DateOfJoining  { get; set; }
        public string Address { get; set; }
        public bool Discontinued { get; set; }
        public bool IsAdmin { get; set; }
    }
}
