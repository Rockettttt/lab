﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingEntity
{
   public  class SalesOrdersEntity
    {
        public int SalesId{ get; set; }
        public int LeadId { get; set; }
        public string ShippingAddress { get; set; }
        public string BillingAddress { get; set; }
        public DateTime CreatedOn { get; set; }
        public string PaymentMode { get; set; }

    }
}
