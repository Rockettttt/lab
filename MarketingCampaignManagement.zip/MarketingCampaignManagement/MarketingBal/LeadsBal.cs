﻿using Marketing_Dal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MarketingBal
{
      public class LeadsBal
    {
        //private static readonly Regex PhoneNo = new Regex("^[8-9]{1}[0-9]{9}+$");
        //private static readonly Regex EmailAddress = new Regex("^ ([a - zA - Z0 - 9_-.] +)@([a - zA - Z0 - 9_.] +).([a - zA - Z]{2, 5})+$");

        private static bool ValidateLead(LeadsEntity lead)
        {
            bool isValidlead = true;
            StringBuilder studentsb = new StringBuilder();


            if (lead.LeadId.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "LeadId  cannot be blank");
            }

            if (lead.ConsumerName.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "ConsumerName name cannot be blank");
            }
            if (lead.DateAppoached.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "DateAppoached name cannot be blank");
            }

            //if (!(Regex.IsMatch(lead.EmailAddress, "^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$")))
            //{
            //    isValidlead = false;
            //    studentsb.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            //}
            if (lead.EmailAddress.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "EmailAddress cannot be blank");
            }

            if (lead.PreferredModeOfCommunication.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "PreferredModeOfCommunication cannot be blank");
            }
            if (lead.PhoneNo.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "PhoneNo cannot be blank");
            }
            //if (!(PhoneNo.IsMatch(lead.PhoneNo)))
            //{
            //    isValidlead = false;
            //    studentsb.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            //}
            if (lead.Status.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "Status cannot be blank");
            }

            if (lead.ProductId.Equals(string.Empty))
            {
                isValidlead = false;
                studentsb.Append(Environment.NewLine + "ProductId cannot be blank");
            }
            if (!isValidlead)

            { throw new Marketing_Exception(studentsb.ToString()); }

            return isValidlead;
        }
        public static bool AddleadBal(LeadsEntity le)
        {
            bool leadadded = false;
            try
            {
                if (ValidateLead(le))
                {
                    LeadsDal leaddal = new LeadsDal();
                    leaddal.UpdateLeadDAL(le);
                }
                else
                {
                    throw new Marketing_Exception("Failed to add lead");
                }

                LeadsDal leadadd = new LeadsDal();
                leadadded = leadadd.AddleadsDal(le);

            }
            catch (Marketing_Exception)
            {
                throw;
            }
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return leadadded;
        }
        public static bool UpdateleadBAL(LeadsEntity lead)
        {
            bool studentupdated = false;
            try
            {
                if (ValidateLead(lead))
                {
                    LeadsDal leaddal = new LeadsDal();
                    leaddal.UpdateLeadDAL(lead);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update lead");
                }
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentupdated;
        }

    }
}
