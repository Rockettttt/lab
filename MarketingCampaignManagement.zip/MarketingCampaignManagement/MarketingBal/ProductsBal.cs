﻿using Marketing_Dal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MarketingBal
{
    public class ProductsBal
    {
        private static bool ValidateUser(ProductsEntity pro)
        {
            bool isValidproduct= true;
            StringBuilder studentsb = new StringBuilder();
            if (pro.ProductId.Equals(string.Empty))
            {
                isValidproduct = false;
                studentsb.Append(Environment.NewLine + "ProductId name cannot be blank");
            }

            if (pro.Name.Equals(string.Empty))
            {
                isValidproduct = false;
                studentsb.Append(Environment.NewLine + "name cannot be blank");
            }
            if (pro.Description.Equals(string.Empty))
            {
                isValidproduct = false;
                studentsb.Append(Environment.NewLine + "Description cannot be blank");
            }

            if (pro.Unitprice.Equals(string.Empty))
            {
                isValidproduct = false;
                studentsb.Append(Environment.NewLine + "Unitprice cannot be blank");
            }
           


            if (!isValidproduct)

            { throw new Marketing_Exception(studentsb.ToString()); }

            return isValidproduct;
        }

        public static bool AddProdcutBal(ProductsEntity product)
        {
            bool productadded = false;
            try
            {
                if (ValidateUser(product))
                {
                    ProductsDal prodal = new ProductsDal();
                    prodal.UpdateProductDAL(product);
                }
                else
                {
                    throw new Marketing_Exception("Failed to add product");
                }

                ProductsDal productadd = new ProductsDal();
                productadded = productadd.AddProductDal(product);

            }
            catch (Marketing_Exception)
            {
                throw;
            }
            

            return productadded;
        }

        public static bool UpdateProducctBAL(ProductsEntity pro)
        {
            bool studentupdated = false;
            try
            {
                if (ValidateUser(pro))
                {
                    ProductsDal prodal = new ProductsDal();
                    prodal.UpdateProductDAL(pro);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update product");
                }
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentupdated;
        }

    }
}
