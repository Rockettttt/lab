﻿using Marketing_Dal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MarketingBal
{
    public class UsersBal
    {
        private static bool ValidateUser(UsersEntity users)
        {
            bool isValidStudent = true;
            StringBuilder studentsb = new StringBuilder();

            if (users.UserId.Equals(string.Empty))
            {
                isValidStudent = false;
                studentsb.Append(Environment.NewLine + "UserId name cannot be blank");
            }
            if (!(Regex.IsMatch(users.FullName, "[A-Z][a-z]{3,}")))
            {
                isValidStudent = false;
                studentsb.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            }
            if (users.FullName.Equals(string.Empty))
            {
                isValidStudent = false;
                studentsb.Append(Environment.NewLine + "FullName name cannot be blank");
            }

            if (!(Regex.IsMatch(users.LoginId, "[A-Z][a-z]{3,}")))
            {
                isValidStudent = false;
                studentsb.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            }
            if (users.LoginId.Equals(string.Empty))
            {
                isValidStudent = false;
                studentsb.Append(Environment.NewLine + "LoginId name cannot be blank");
            }
           
            if (users.Password.Equals(string.Empty))
            {
                isValidStudent = false;
                studentsb.Append(Environment.NewLine + "Password cannot be blank");
            }
            if (!(Regex.IsMatch(users.Password, "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{4,}$")))
            {
                isValidStudent = false;
                studentsb.Append("Password Should Have Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character: " + Environment.NewLine);
            }
            if (users.IsAdmin.Equals(string.Empty))
            {
                isValidStudent = false;
                studentsb.Append(Environment.NewLine + "IsAdmin cannot be blank");
            }
          
           
            if (!isValidStudent)

            { throw new Marketing_Exception(studentsb.ToString()); }

            return isValidStudent;
        }
        public static bool AddUserBal(UsersEntity ue)
        {
            bool Useradded = false;
            try
            {
                if (ValidateUser(ue))
                {
                    UsersDal usedal = new UsersDal();
                    usedal.UpdateUserDAL(ue);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update USER");
                }


                UsersDal useradd = new UsersDal();
                Useradded = useradd.AddUsersDal(ue);
               

            }
            catch (Marketing_Exception)
            {
                throw;
            }
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return Useradded;
        }

        public static bool UpdateUserBAL(UsersEntity user)
        {
            bool studentupdated = false;
            try
            {
                if (ValidateUser(user))
                {
                    UsersDal usedal = new UsersDal();
                    usedal.UpdateUserDAL(user);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update USER");
                }
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentupdated;
        }

    }
}
