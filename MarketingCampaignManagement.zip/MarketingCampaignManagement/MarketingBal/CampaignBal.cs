﻿using Marketing_Dal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingBal
{
   public class CampaignBal
    {
        private static bool Validatecampiagn(CampaignsEntity camp)
        {
            bool isValidcampaign = true;
            StringBuilder studentsb = new StringBuilder();


            if (camp.CampaignId.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + " CampaignId cannot be blank");
            }
           
            if (camp.Name.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + " Name cannot be blank");
            }
            if (camp.Venue.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + "Venue cannot be blank");
            }

            if (camp.AssignedTo.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + "Assignedto cannot be blank");
            }
            if (camp.CompletedOn.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + "CompletedOn cannot be blank");
            }
            if (camp.IsOpen.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + "IsOpen cannot be blank");
            }

            if (camp.StartedOn.Equals(string.Empty))
            {
                isValidcampaign = false;
                studentsb.Append(Environment.NewLine + "StartedOn cannot be blank");
            }
            if (!isValidcampaign)

            { throw new Marketing_Exception(studentsb.ToString()); }

            return isValidcampaign;
        }
        public static bool AddCampaignBal(CampaignsEntity camp)
        {
            bool campaignadded = false;
            try
            {
                if (Validatecampiagn(camp))
                {
                    CampiagnDal campdal = new CampiagnDal();
                    campdal.UpdatecampaignDAL(camp);
                }
                else
                {
                    throw new Marketing_Exception("Failed to add campiagn");
                }

                CampiagnDal campadd = new CampiagnDal();
          
                campaignadded = campadd.AddcampiagnDal(camp);

            }
            catch (Marketing_Exception)
            {
                throw;
            }
            

            return campaignadded;
        }

        public static bool UpdatecampaignBAL(CampaignsEntity camp)
        {
            bool studentupdated = false;
            try
            {
                if (Validatecampiagn(camp))
                {
                    CampiagnDal campdal = new CampiagnDal();
                    campdal.UpdatecampaignDAL(camp);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update campiagn");
                }
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentupdated;
        }
    }
}

