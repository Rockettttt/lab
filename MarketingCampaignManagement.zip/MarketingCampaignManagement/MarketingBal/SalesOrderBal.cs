﻿using Marketing_Dal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketingBal
{
    public class SalesOrderBal
    {
        private static bool Validatesalesorder(SalesOrdersEntity sale)
        {
            bool isValidSalesorder = true;
            StringBuilder studentsb = new StringBuilder();

            
           
            if (sale.SalesId.Equals(string.Empty))
            {
                isValidSalesorder = false;
                studentsb.Append(Environment.NewLine + "SalesId name cannot be blank");
            }
            if (sale.ShippingAddress.Equals(string.Empty))
            {
                isValidSalesorder = false;
                studentsb.Append(Environment.NewLine + "ShippingAddress  cannot be blank");
            }

            if (sale.CreatedOn.Equals(string.Empty))
            {
                isValidSalesorder = false;
                studentsb.Append(Environment.NewLine + "CreatedOn cannot be blank");
            }
            if (sale.ShippingAddress.Equals(string.Empty))
            {
                isValidSalesorder = false;
                studentsb.Append(Environment.NewLine + "ShippingAddress cannot be blank");
            }


            if (!isValidSalesorder)

            { throw new Marketing_Exception(studentsb.ToString()); }

            return isValidSalesorder;
        }
        public static bool AddleadBal(SalesOrdersEntity sale)
        {
            bool saleorderadded = false;
            try
            {

                if (Validatesalesorder(sale))
                {
                    SalesOrderDal saledal = new SalesOrderDal();
                    saledal.UpdatesalesorderDAL(sale);
                }
                else
                {
                    throw new Marketing_Exception("Failed to add salesorder");
                }

                SalesOrderDal saleadd = new SalesOrderDal();
                saleorderadded = saleadd.AddSalesOrderDal(sale);

            }
            catch (Marketing_Exception)
            {
                throw;
            }
           
            return saleorderadded;
        }

        public static bool UpdatesalesorderBAL(SalesOrdersEntity sale)
        {
            bool studentupdated = false;
            try
            {
                if (Validatesalesorder(sale))
                {
                    SalesOrderDal saledal = new SalesOrderDal();
                    saledal.UpdatesalesorderDAL(sale);
                }
                else
                {
                    throw new Marketing_Exception("Failed to update salesorder");
                }
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentupdated;
        }
    }
}
