﻿using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marketing_Dal
{
    public class LeadsDal
    {
        static string ConnectionString = string.Empty;
        SqlConnection connection = null;
        SqlCommand cmd = null;
        static LeadsDal()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public LeadsDal()
        {
            connection = new SqlConnection(ConnectionString);

        }
        public bool AddleadsDal(LeadsEntity lead)
        {
            bool leadAdded = false;
            try

            {
              
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vinay].[addlead_172309]";
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@CampaignId", lead.CampaignId);
                Command.Parameters.AddWithValue("@ConsumerName", lead.ConsumerName);
                Command.Parameters.AddWithValue("@EmailAddress", lead.EmailAddress);
                Command.Parameters.AddWithValue("@PhoneNo", lead.PhoneNo);
                Command.Parameters.AddWithValue("@PreferredModeOfCommunication", lead.PreferredModeOfCommunication);
                Command.Parameters.AddWithValue("@DateAppoached", lead.DateAppoached);
                Command.Parameters.AddWithValue("@ProductId", lead.ProductId);
                Command.Parameters.AddWithValue("@Status", lead.Status);
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    leadAdded = true;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            return leadAdded;
        }

        public void UpdateLeadDAL(LeadsEntity lead)
        {
            try
            {
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "UPDATE  vinay.Leads SET CampaignId=@CampaignId,ConsumerName=@ConsumerName,EmailAddress=@EmailAddress,PhoneNo=@PhoneNo,PreferredModeOfCommunication=@PreferredModeOfCommunication,DateAppoached=@DateAppoached,Status=@Status WHERE LeadId=@LeadId";

                Command.Parameters.AddWithValue("@LeadId", lead. LeadId);
                Command.Parameters.AddWithValue("@CampaignId", lead .CampaignId);
                Command.Parameters.AddWithValue("@ConsumerName", lead. ConsumerName);
                Command.Parameters.AddWithValue("@EmailAddress", lead.EmailAddress);
                Command.Parameters.AddWithValue("@PhoneNo", lead. PhoneNo);
                Command.Parameters.AddWithValue("@PreferredModeOfCommunication", lead.PreferredModeOfCommunication);
                Command.Parameters.AddWithValue("@DateAppoached", lead. DateAppoached);
                Command.Parameters.AddWithValue("@ProductId", lead.ProductId);
                Command.Parameters.AddWithValue("@Status", lead.Status);
                Command.CommandText = query;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();



            }
            catch (Marketing_Exception)
            {
                throw;
            }
        }
    }
}
