﻿
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marketing_Dal
{
    public class ProductsDal
    {
        static string ConnectionString = string.Empty;
        SqlConnection connection = null;
        SqlCommand cmd = null;
        static ProductsDal()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public ProductsDal()
        {
            connection = new SqlConnection(ConnectionString);

        }
        public bool AddProductDal(ProductsEntity Pro)
        {
            bool productadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vinay].[AddProducts_172309]";
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@Name", Pro.Name);
                Command.Parameters.AddWithValue("@Description", Pro.Description);
                Command.Parameters.AddWithValue("@Unitprice", Pro.Unitprice);


                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    productadded = true;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            return productadded;
        }


        public void UpdateProductDAL(ProductsEntity pro)
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
               
                string query = "UPDATE  vinay.Products SET Name=@Name,Description=@Description,Unitprice=@Unitprice WHERE ProductId=@ProductId";
                Command.Parameters.AddWithValue("@ProductId", pro. ProductId);
                Command.Parameters.AddWithValue("@Name", pro .Name);
                Command.Parameters.AddWithValue("@Description", pro .Description);
                Command.Parameters.AddWithValue("@Unitprice", pro.Unitprice);

                Command.CommandText = query;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
            }
            catch (Marketing_Exception)
            {
                throw;
            }
        }

    }

}
