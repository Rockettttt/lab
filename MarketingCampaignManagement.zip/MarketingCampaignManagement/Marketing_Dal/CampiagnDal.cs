﻿using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketingEntity;

namespace Marketing_Dal
{
   public  class CampiagnDal
    {
        static string ConnectionString = string.Empty;
        SqlConnection connection = new SqlConnection();
        SqlCommand Command = new SqlCommand();

        static CampiagnDal()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public CampiagnDal()
        {
            connection = new SqlConnection(ConnectionString);

        }

        public bool AddcampiagnDal(CampaignsEntity camp)
        {
            bool campaignadd = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vinay].[addcampaign_172309]";
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                Command.Parameters.AddWithValue("@Name", camp.Name);
                Command.Parameters.AddWithValue("@Venue", camp.Venue);
                Command.Parameters.AddWithValue("@AssignedTo", camp.AssignedTo);
                Command.Parameters.AddWithValue("@StartedOn", camp.StartedOn);
                Command.Parameters.AddWithValue("@CompletedOn", camp.CompletedOn);
                Command.Parameters.AddWithValue("@IsOpen", camp.IsOpen);
            
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    campaignadd = true;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            return campaignadd;
        }


        public void UpdatecampaignDAL(CampaignsEntity camp)
        {
            try
            {
                //connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                
                
                string query = "UPDATE  vinay.Campaigns SET Name=@Name,Venue=@Venue,AssignedTo=@AssignedTo,StartedOn=@StartedOn,CompletedOn=@CompletedOn,IsOpen=@IsOpen WHERE CampaignId=@CampaignId";
                SqlCommand Command = new SqlCommand(query,connection);
                Command.Connection = connection;
                Command.Parameters.AddWithValue("@CampaignId", camp. CampaignId);
                Command.Parameters.AddWithValue("@Name", camp .Name);
                Command.Parameters.AddWithValue("@Venue", camp. Venue);
                Command.Parameters.AddWithValue("@AssignedTo", camp .AssignedTo);
                Command.Parameters.AddWithValue("@StartedOn", camp.StartedOn);
                Command.Parameters.AddWithValue("@CompletedOn", camp .CompletedOn);
                Command.Parameters.AddWithValue("@IsOpen", camp .IsOpen);


                Command.CommandText = query;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
        }
    }
}
