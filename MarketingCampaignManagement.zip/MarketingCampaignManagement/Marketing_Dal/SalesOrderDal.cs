﻿using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marketing_Dal
{
   public class SalesOrderDal
    {
        static string ConnectionString = string.Empty;
        SqlConnection connection = null;
        SqlCommand Command = null;
        static SalesOrderDal()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public SalesOrderDal()
        {
            connection = new SqlConnection(ConnectionString);

        }
        public bool AddSalesOrderDal(SalesOrdersEntity sale)
        {
            bool salesorderAdded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vinay].[addsaleoders_172309]";
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
              
                Command.Parameters.AddWithValue("@LeadId", sale.LeadId);
                Command.Parameters.AddWithValue("@ShippingAddress", sale.ShippingAddress);
                Command.Parameters.AddWithValue("@BillingAddress", sale.BillingAddress);
                Command.Parameters.AddWithValue("@CreatedOn", sale.CreatedOn);
                Command.Parameters.AddWithValue("@PaymentMode", sale.PaymentMode);
               
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    salesorderAdded = true;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            return salesorderAdded;
        }


        public void UpdatesalesorderDAL(SalesOrdersEntity sal)
        {
            try
            {
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "update vinay.SalesOrders SET ShippingAddress=@ShippingAddress,BillingAddress=@BillingAddress,CreatedOn=@CreatedOn,PaymentMode=@PaymentMode WHERE LeadId=@LeadId";

                Command.Parameters.AddWithValue("@LeadId", sal .LeadId);
                Command.Parameters.AddWithValue("@ShippingAddress", sal.ShippingAddress);
                Command.Parameters.AddWithValue("@BillingAddress", sal. BillingAddress);
                Command.Parameters.AddWithValue("@CreatedOn", sal.CreatedOn);
                Command.Parameters.AddWithValue("@PaymentMode", sal. PaymentMode);
                Command.CommandText = query;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
            }
            catch (Marketing_Exception)
            {
                throw;
            }
        }

    }
}
