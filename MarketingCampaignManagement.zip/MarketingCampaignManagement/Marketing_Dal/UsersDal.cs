﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketingEntity;
using MarketingException;

namespace Marketing_Dal
{
    public class UsersDal
    {
        static string ConnectionString = string.Empty;
        SqlConnection connection = null;
        SqlCommand cmd = null;
        static UsersDal()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public UsersDal()
        {
            connection = new SqlConnection(ConnectionString);

        }
        public bool AddUsersDal(UsersEntity users)
        {
            bool UserAdded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vinay].[adduser_172309]";
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@FullName", users.FullName);
                Command.Parameters.AddWithValue("@LoginId", users.LoginId);
                Command.Parameters.AddWithValue("@Password ", users.Password);
                Command.Parameters.AddWithValue("@DateOfJoining  ", users.DateOfJoining);
                Command.Parameters.AddWithValue("@Address", users.Address);
                Command.Parameters.AddWithValue("@Discontinued ", users.Discontinued);
                Command.Parameters.AddWithValue("@IsAdmin ", users.IsAdmin);            
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                   UserAdded = true;
            }
            catch (Marketing_Exception)
            {
                throw;
            }
            return UserAdded;
        }



        public void UpdateUserDAL(UsersEntity user)
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "UPDATE  vinay.Users SET FullName=@FullName,LoginId=@LoginId,Password=@Password,DateOfJoining=@DateOfJoining,Address=@Address,Discontinued=@Discontinued,IsAdmin=@IsAdmin WHERE UserId=@UserId";
                Command.Parameters.AddWithValue("@UserId", user.UserId);
                Command.Parameters.AddWithValue("@FullName", user.FullName);
                Command.Parameters.AddWithValue("@LoginId", user.LoginId);
                Command.Parameters.AddWithValue("@Password", user.Password);
                Command.Parameters.AddWithValue("@DateOfJoining", user. DateOfJoining);
                Command.Parameters.AddWithValue("@Address", user. Address);
                Command.Parameters.AddWithValue("@Discontinued", user. Discontinued);
                Command.Parameters.AddWithValue("@IsAdmin", user.IsAdmin);

                Command.CommandText = query;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
               
            }
            catch (Marketing_Exception)
            {
                throw;
            }
        }

        }
    }

