﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for UpdateLeads_Page.xaml
    /// </summary>
    public partial class UpdateLeads_Page : Window
    {
        public UpdateLeads_Page()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LeadsEntity le = new LeadsEntity();
            le .LeadId = int.Parse(txt_leadid.Text);
            le. CampaignId = int.Parse(txt_campaignid.Text);
            le. ConsumerName = txt_consumername.Text;
            le. EmailAddress = txt_Email.Text;
            le .PhoneNo = txt_phoneno.Text;
            le .PreferredModeOfCommunication = txt_prefermode.Text;
            le .DateAppoached = DateTime.Parse(datePicker1.Text);
            le. ProductId = int.Parse(txt_productid.Text);
            le.  Status = cmbstatus.Text;
            UpdateLeadPL(le);


        }
        private static void UpdateLeadPL(LeadsEntity lead)
        {
            try
            {
                bool studentUpdated = LeadsBal.UpdateleadBAL(lead);
                if (studentUpdated)
                    MessageBox.Show("lead not Updated");
                else
                    MessageBox.Show("lead Updated");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void executivepage_Click(object sender, RoutedEventArgs e)
        {
            executive_Page ex = new executive_Page();
            ex.Show();
            this.Close();
        }
    }
}

