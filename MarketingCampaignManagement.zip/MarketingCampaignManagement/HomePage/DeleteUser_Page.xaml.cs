﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for DeleteUser_Page.xaml
    /// </summary>
    public partial class DeleteUser_Page : Window
    {
        public DeleteUser_Page()
        {
            InitializeComponent();
        }
        public void LoadGrid()
        {
            SqlConnection connection = new SqlConnection();
            try
            {
                //// connection = new SqlConnection();
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "SELECT * FROM vinay.Users ";

                Command.CommandText = query;
                SqlDataReader Reader = Command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgUser.DataContext = Table;
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured." + Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured." + Exception.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }

        }
       
        
        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {

            int UserId = int.Parse(textBoxEmployeeId.Text);
            SqlConnection connection = new SqlConnection();
            try
            {
                //// connection = new SqlConnection();
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "DELETE  FROM  vinay.Users WHERE UserId=" + UserId;

                Command.CommandText = query;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                {
                    MessageBox.Show("User Details Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to delete User.");
                }
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured." + Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured." + Exception.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }
    }
}
