﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for UpdateProducts_Page.xaml
    /// </summary>
    public partial class UpdateProducts_Page : Window
    {
        public UpdateProducts_Page()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            ProductsEntity pro = new ProductsEntity();
            pro. ProductId = int.Parse(txt_productid.Text.ToString());
            pro. Name = txt_name.Text;
            pro. Description = txt_description.Text;
            pro. Unitprice = decimal.Parse(txt_price.Text.ToString());
            UpdateProductPL(pro);
        }

        private static void UpdateProductPL(ProductsEntity pro)
        {
            try
            {
                bool studentUpdated = ProductsBal.UpdateProducctBAL(pro);
                if (studentUpdated)
                    MessageBox.Show("Product not Updated");
                else
                    MessageBox.Show("Product Updated");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void AdminPage_Click(object sender, RoutedEventArgs e)
        {
            Admin_Page admin = new Admin_Page();
            admin.Show();
            this.Close();

        }
    }
}
