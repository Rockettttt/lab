﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for AddLead_Page.xaml
    /// </summary>
    /// 
    public partial class AddLead_Page : Window
    {
        
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;


        public AddLead_Page()
        {
            InitializeComponent();
        }
       


        private void executivepage_Click(object sender, RoutedEventArgs e)
        {
            executive_Page expage = new executive_Page();
            expage.Show();
            this.Close();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            bool value = true;
            if (datePicker1.Text == string.Empty)
            {
                MessageBox.Show("Date must be select");
                value = false;
            }
            if (value)
            {
                if (cmbstatus.Text == "Won")
                {
                    string leadid = txt_leadid.Text;
                    SalesOrder_Page sp = new SalesOrder_Page(leadid);
                    sp.Show();
                    this.Close();

                }
                if (cmbstatus.Text == "Lost")
                {
                    MessageBox.Show("lead is not Interested");
                }
                if (cmbstatus.Text == "New")
                {
                    MessageBox.Show("New Lead ");
                }

                LeadsEntity le = new LeadsEntity();
                le.CampaignId = int.Parse(txt_campaignid.Text);
                le.ConsumerName = txt_consumername.Text;
                le.EmailAddress = txt_Email.Text;
                le.PhoneNo = txt_phoneno.Text;
                le.PreferredModeOfCommunication = txt_prefermode.Text;
                le.DateAppoached = DateTime.Parse(datePicker1.Text);
                le.ProductId = int.Parse(txt_productid.Text);
                le.Status = cmbstatus.Text;


                Addlead(le);

            }

        }
        public void Addlead(LeadsEntity le)
        {
            try
            {
           
                bool UserAdded = LeadsBal.AddleadBal(le);
                if (UserAdded)
                    MessageBox.Show("Lead Added");
                else
                    MessageBox.Show("Lead not Added");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('vinay.Leads') + ident_incr('vinay.Leads')", SqlConnection);
            try
            {
       
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                txt_leadid.Text = nxId.ToString();

                

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();
            }
        }
    }
    }

