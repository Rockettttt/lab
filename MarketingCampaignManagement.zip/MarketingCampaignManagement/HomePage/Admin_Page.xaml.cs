﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
   
    public partial class Admin_Page : Window
    {
        public Admin_Page()
        {
            InitializeComponent();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            User_Page UserPage = new User_Page();
            UserPage.Show();
            this.Close();
        }

       

        private void CreateCampaign_Click(object sender, RoutedEventArgs e)
        {
            Campaign_Page campaignpage = new Campaign_Page();
            campaignpage.Show();
            this.Close();
        }

        private void HomePage_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            Product_page pro = new Product_page();
            pro.Show();
            this.Close();
        }

        private void UpdateUser_Click(object sender, RoutedEventArgs e)
        {
            UpdateUser_Page user = new UpdateUser_Page();
            user.Show();
            this.Close();
        }
   
        private void UpdateCapamiagn_Click(object sender, RoutedEventArgs e)
        {
            UpdateCampaign_Page uc = new UpdateCampaign_Page();
            uc.Show();
            this.Close();
        }

        private void UpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            UpdateProducts_Page up = new UpdateProducts_Page();
            up.Show();
            this.Close();

        }

       
        private void UpdateProduct_Click_1(object sender, RoutedEventArgs e)
        {
            UpdateProducts_Page up = new UpdateProducts_Page();
            up.Show();
            this.Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ViewLead_Page vp = new ViewLead_Page();
            vp.Show();
            this.Close();
        }

        private void MenuItem1_Click(object sender, RoutedEventArgs e)
        {
            ViewCampaign_Page vc = new ViewCampaign_Page();
            vc.Show();
            this.Close();
        }
    }
}
