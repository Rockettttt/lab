﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for Viewleadsbycampaign_Page.xaml
    /// </summary>
    public partial class Viewleadsbycampaign_Page : Window
    {
        public Viewleadsbycampaign_Page()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }
        public void LoadGrid()
        {
            int CampaignId = int.Parse(text_id.Text);
            SqlConnection connection = new SqlConnection();
            try
            {
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "  SELECT  L.LeadId, L.ConsumerName, L.CampaignId,C.AssignedTo FROM vinay.Leads L  RIGHT OUTER JOIN vinay.Campaigns C ON L.CampaignId = C.CampaignId where AssignedTo = @AssignedTo";
                Command.Parameters.AddWithValue("@AssignedTo", CampaignId);
                Command.CommandText = query;
                SqlDataReader Reader = Command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgLead.DataContext = Table;
                dgLead.Visibility = Visibility.Visible;
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }
    }
}
