﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for User_Page.xaml
    /// </summary>
    public partial class User_Page : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public User_Page()
        {
            InitializeComponent();
        }

        private void AdminPage_Click(object sender, RoutedEventArgs e)
        {
            Admin_Page admin = new Admin_Page();
            admin.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UsersEntity ue = new UsersEntity();
            ue.FullName = text_fullname.Text;
            ue.LoginId = text_loginid.Text;
            ue.Password = text_pwd.Password.ToString();
            ue.DateOfJoining = DateTime.Parse(datePicker1.ToString());
            ue.Address = text_address.Text;
            ue.Discontinued = Boolean.Parse(combobox1.Text);
            ue.IsAdmin = Boolean.Parse(combobox2.Text);
            AddUser(ue);

        }
        private static void AddUser(UsersEntity user)
        {
            try
            {
                bool UserAdded = UsersBal.AddUserBal(user);
                if (UserAdded)
                    MessageBox.Show("User Added");
                else
                    MessageBox.Show("User not Added");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('vinay.Users') + ident_incr('vinay.Users')", SqlConnection);
            try
            {
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                text_userid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();
            }
        }


    }
}


