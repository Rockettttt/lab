﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for executive_Page.xaml
    /// </summary>
    public partial class executive_Page : Window
    {
      
        public executive_Page()
        {
            InitializeComponent();
        }
        

        private void AddLead_Click(object sender, RoutedEventArgs e)
        {
            AddLead_Page addlead = new AddLead_Page();
            addlead.Show();
            this.Close();
            
        }

        private void Salesorders_Click(object sender, RoutedEventArgs e)
        {
            SalesOrder_Page salespage = new SalesOrder_Page();
            salespage.Show();
            this.Close();
        }

        private void HomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void UpdateLead_Click(object sender, RoutedEventArgs e)
        {
            UpdateLeads_Page ul = new UpdateLeads_Page();
            ul.Show();
            this.Close();
        }

      

        private void MenuItem2_Click(object sender, RoutedEventArgs e)
        {
            Viewleadsbycampaign_Page vlc = new Viewleadsbycampaign_Page();
            vlc.Show();
            
        }

        private void UpdateOrders_Click_1(object sender, RoutedEventArgs e)
        {
            UpdateSalesOrder_page us = new UpdateSalesOrder_page();
            us.Show();
            this.Close();

        }
    }
}
