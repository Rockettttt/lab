﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for UpdateCampaign_Page.xaml
    /// </summary>
    public partial class UpdateCampaign_Page : Window
    {
        public UpdateCampaign_Page()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            CampaignsEntity ce = new CampaignsEntity();
            ce.CampaignId = int.Parse(txt_campaignid.Text);
            ce .Name = txt_name.Text;
            ce. Venue = txt_venue.Text;
            ce. AssignedTo = int.Parse(txt_assignedto.Text);
            ce .StartedOn = DateTime.Parse(txt_datePicker1.ToString());
            ce .CompletedOn = DateTime.Parse(txt_datePicker2.ToString());
            ce .IsOpen = Boolean.Parse(combobox1.Text);
            UpdatecampaignPL(ce);
        }

        private static void UpdatecampaignPL(CampaignsEntity camp)
        {
            try
            {
                bool studentUpdated = CampaignBal.UpdatecampaignBAL(camp);
                if (studentUpdated)
                    MessageBox.Show("Student not Updated");
                else
                    MessageBox.Show("Student Updated");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AdminPage_Click(object sender, RoutedEventArgs e)
        {
            Admin_Page admin = new Admin_Page();
            admin.Show();
            this.Close();
        }
    }
}
