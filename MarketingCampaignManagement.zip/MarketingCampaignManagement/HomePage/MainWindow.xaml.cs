﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (combobox1.Text == "Admin")
            {
                if (txt_id.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("USER Id Cannot be Empty");
                    return; // return because we don't want to run normal code of buton click
                }
                else if (password.Password.Trim() == string.Empty)
                {
                    MessageBox.Show("Password Cannot be Empty");
                    return; // return because we don't want to run normal code of buton click
                }

                if (txt_id.Text != "admin")
                {
                    MessageBox.Show("Invalid login Id");
                }
                if (password.Password != "admin")
                {
                    MessageBox.Show("Invalid Password");
                }
                else
                {
                    Admin_Page admin = new Admin_Page();
                    admin.Show();
                }
                //MessageBox.Show("select combobox admin as option");
            }
             
 

            if (combobox1.Text == "")
            {
                MessageBox.Show("please select an option");
            }



            
            if (combobox1.Text == "Executives")
            {
                string constring = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                SqlConnection connection = new SqlConnection(constring);
                try
                {
                    bool value = true;
                    if (txt_id.Text.Trim() == string.Empty)
                    {
                        MessageBox.Show("user Id Cannot be Empty");
                        return; // return because we don't want to run normal code of buton click
                    }
                    else if (password.Password.Trim() == string.Empty)
                    {
                        MessageBox.Show("Password Cannot be Empty");
                        return; // return because we don't want to run normal code of buton click
                    }
                    else if (txt_exeid.Text.Trim() == string.Empty)
                    {
                        MessageBox.Show("executive id Cannot be Empty");
                        return; // return because we don't want to run normal code of buton click

                    }
                   
                    connection.Open();
                    string query = "select LoginId,Password from vinay.Users where LoginId ='" + txt_id.Text + "' and Password='" + password.Password.ToString() + "'and UserId ='" + txt_exeid.Text + "' ";
                   
                    SqlCommand cmd = new SqlCommand(query, connection);
                   


                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        
                        MessageBox.Show("Login Successful");
                        string loginid = txt_id.Text;
                        string UserId = txt_exeid.Text;
                        executive_Page ep = new executive_Page();
                        ep.Show();
                        this.Close();
                        //this.NavigationService.Navigate(new Uri("Home_Page.xaml", UriKind.RelativeOrAbsolute));
                    }

                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                    }


                }

                catch (SqlException)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            txt_id.Text = string.Empty;
            password.Password = string.Empty;
            txt_exeid.Text= string.Empty;

        }
    }
    }

