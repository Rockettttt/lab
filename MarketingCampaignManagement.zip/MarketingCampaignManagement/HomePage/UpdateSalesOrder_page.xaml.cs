﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for UpdateSalesOrder_page.xaml
    /// </summary>
    public partial class UpdateSalesOrder_page : Window
    {
        public UpdateSalesOrder_page()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SalesOrdersEntity sale = new SalesOrdersEntity();
            sale .SalesId = int.Parse(txt_orderid.Text);
            sale .LeadId = int.Parse(txt_leadid.Text);
            sale. ShippingAddress = txt_shippingaddress.Text;
            sale .BillingAddress = txt_billingaddress.Text;
            sale.CreatedOn = DateTime.Parse(datePicker1.Text);
            sale. PaymentMode = txt_comboboxsales.Text;
           
            Updatesalesorderpl(sale);



        }


        private static void Updatesalesorderpl(SalesOrdersEntity sale)
        {
            try
            {
                bool studentUpdated = SalesOrderBal.UpdatesalesorderBAL(sale);
                if (studentUpdated)
                    MessageBox.Show("salesorder not Updated");
                else
                    MessageBox.Show("salesorder Updated");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }


}


