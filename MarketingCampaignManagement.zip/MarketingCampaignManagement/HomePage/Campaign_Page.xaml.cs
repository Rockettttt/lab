﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for Campaign_Page.xaml
    /// </summary>
    public partial class Campaign_Page : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public Campaign_Page()
        {
            InitializeComponent();
        }

        private void AdminPage_Click(object sender, RoutedEventArgs e)
        {
            Admin_Page admin = new Admin_Page();
            admin.Show();
            this.Close();
        }

       
        private static void Addcampaign(CampaignsEntity camp)
        {
            try
            {
                bool campaignadded = CampaignBal.AddCampaignBal(camp);
                if (campaignadded)
                    MessageBox.Show("campaign Added");
                else
                    MessageBox.Show("campaign not Added");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('vinay.Campaigns') + ident_incr('vinay.Campaigns')", SqlConnection);
            try
            {
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                txt_campaignid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CampaignsEntity ce = new CampaignsEntity();
            ce.Name = txt_name.Text;
            ce.Venue = txt_venue.Text;
            ce.AssignedTo = int.Parse(txt_assignedto.Text);
            ce.StartedOn = DateTime.Parse(txt_datePicker1.ToString());
            ce.CompletedOn = DateTime.Parse(txt_datePicker2.ToString());
            ce.IsOpen = Boolean.Parse(combobox1.Text);
            Addcampaign(ce);
        }
    }
}
