﻿using MarketingBal;
using MarketingEntity;
using MarketingException;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for UpdateUser_Page.xaml
    /// </summary>
    public partial class UpdateUser_Page : Window
    {
        public UpdateUser_Page()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            UsersEntity users = new UsersEntity();
            users.UserId = int.Parse(text_userid.Text);
            users. FullName = text_fullname.Text;
            users. LoginId = text_loginid.Text;
            users. Password = text_pwd.Password.ToString();
            users. DateOfJoining = DateTime.Parse(datePicker1.Text);
            users. Address = text_address.Text;
            users .Discontinued = bool.Parse(combobox1.Text);
            users. IsAdmin = bool.Parse(combobox2.Text);
            if (text_userid.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Users Id Cannot be Empty");
                return;
            }
            UpdateUserPL(users);

           

        }
        private static void UpdateUserPL(UsersEntity users)
        {
            try
            {
                bool studentUpdated = UsersBal.UpdateUserBAL(users);
                if (studentUpdated)
                    MessageBox.Show("Student not Updated");
                else
                    MessageBox.Show("Student Updated");
            }
            catch (Marketing_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AdminPage_Click(object sender, RoutedEventArgs e)
        {
            Admin_Page admin = new Admin_Page();
            admin.Show();
            this.Close();

        }
    }
}
