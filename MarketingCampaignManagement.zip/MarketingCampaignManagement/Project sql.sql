CREATE TABLE [vinay].[Campaigns] (
    [CampaignId]  INT           IDENTITY (1, 1) NOT NULL,
    [Name]        VARCHAR (30)  NULL,
    [Venue]       VARCHAR (200) NULL,
    [AssignedTo]  INT           NULL,
    [StartedOn]   DATETIME      NULL,
    [CompletedOn] DATETIME      NULL,
    [IsOpen]      BIT           NULL,
    PRIMARY KEY CLUSTERED ([CampaignId] ASC),
    FOREIGN KEY ([AssignedTo]) REFERENCES [vinay].[Users] ([UserId])
);

CREATE TABLE [vinay].[Leads] (
    [LeadId]                       INT          IDENTITY (1, 1) NOT NULL,
    [CampaignId]                   INT          NULL,
    [ConsumerName]                 VARCHAR (30) NULL,
    [EmailAddress]                 VARCHAR (30) NULL,
    [PhoneNo]                      VARCHAR (10) NULL,
    [PreferredModeOfCommunication] VARCHAR (5)  NULL,
    [DateAppoached]                DATETIME     NULL,
    [ProductId]                    INT          NULL,
    [Status]                       VARCHAR (4)  NULL,
    PRIMARY KEY CLUSTERED ([LeadId] ASC),
    FOREIGN KEY ([CampaignId]) REFERENCES [vinay].[Campaigns] ([CampaignId]),
    FOREIGN KEY ([ProductId]) REFERENCES [vinay].[Products] ([ProductId])
);

CREATE TABLE [vinay].[Products] (
    [ProductId]   INT           IDENTITY (1, 1) NOT NULL,
    [Name]        VARCHAR (20)  NULL,
    [Description] VARCHAR (300) NULL,
    [Unitprice]   DECIMAL (18)  NULL,
    PRIMARY KEY CLUSTERED ([ProductId] ASC)
);


CREATE TABLE [vinay].[SalesOrders] (
    [OrderId]         INT           IDENTITY (1, 1) NOT NULL,
    [LeadId]          INT           NULL,
    [ShippingAddress] VARCHAR (200) NULL,
    [BillingAddress]  VARCHAR (200) NULL,
    [CreatedOn]       DATETIME      NULL,
    [PaymentMode]     VARCHAR (10)  NULL,
    PRIMARY KEY CLUSTERED ([OrderId] ASC),
    FOREIGN KEY ([LeadId]) REFERENCES [vinay].[Leads] ([LeadId])
);

CREATE TABLE [vinay].[Users] (
    [UserId]        INT           IDENTITY (1, 1) NOT NULL,
    [FullName]      VARCHAR (25)  NULL,
    [LoginId]       VARCHAR (30)  NULL,
    [Password]      VARCHAR (30)  NULL,
    [DateOfJoining] DATETIME      NULL,
    [Address]       VARCHAR (200) NULL,
    [Discontinued]  BIT           NULL,
    [IsAdmin]       BIT           NULL,
    PRIMARY KEY CLUSTERED ([UserId] ASC)
);

select * from  [vinay].[Campaigns]